const iklan = () => { 
	return `           
╔══✪〘 MARKOS 〙✪══
║
╠═══════════════════════════
╠➥ *LISTA DE ALUGUEL E CRIAR BOT: *
╠➥ * ALUGUEL: 10K / GRUPO (MÊS) *
╠➥ * CRIAR: 35K (PODE SER PROPRIETÁRIO) *
╠➥ * PODE PAGAR ATRAVÉS DE: *
╠➥ * MERCADO PAGO *
╠═══════════════════════════
╠➥ *BENEFÍCIOS DO BOT DE ALUGUEL: *
╠➥ * 1. PODE SER UM Rizky ADMIN *
╠➥ * 2. PODE OBTER COMANDO ADMIN *
╠➥ *VANTAGENS PARA BOT: *
╠➥ * 1. PODE SER SEU PRÓPRIO PROPRIETÁRIO DO BOT *
╠➥ * 2. PODE ALTERAR O NOME DO PRÓPRIO BOT *
╠➥ * 3. PODE TRAZER BOTS PARA O GRUPO *
╠➥ * 4. PODE USAR O PROPRIETÁRIO DO COMANDO *
╠➥ * 5. PODE ALUGAR OS BOTS DE VOLTA *
╠═══════════════════════════
╠➥ *EM CASO DE PUBLICIDADE DE INTERESSE *
╠➥ * ENTRE EM CONTATO COM O NÚMERO ABAIXO: *
╠➥ *https://api.whatsapp.com/send?phone=5594988088531*
║
╚═〘  MARKOS BOT 〙

Seguidores do pedido? Assinantes etc.
Completar jogos de diamantes?
Alugou uma chave de API?
Junte-se ao negócio de influenciadores?
Lista de gerenciamento de Selebgram?
Contate o proprietário do centro! 
Clique em https://api.whatsapp.com/send?phone=5595988088531


`
}
exports.iklan = iklan