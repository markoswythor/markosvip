const help = (prefix) => { 
	return `
╭───᯽─┈ ┈ ┈┈ ┈╮
┊𝖴𝗉𝖽𝖺𝗍𝖾 𝖵4.678.09
┃┈┈╭────────╯
┃𝖭ome : MARKOS DOMINA
┃𝖯𝗋𝖾𝖿𝗂𝗑 : ❴ / ❵
┃𝖠𝗎𝗍𝗁𝗈𝗋 : MARKOS OFFICIAL
┃𝖨𝗇𝗌𝗍𝖺𝗀𝗋𝖺𝗆 : @markoswythor
┃𝖶𝗁𝖺𝗍𝗌𝖺𝗉𝗉 : wa.me/5594988088531
┃reparação : atualizado 29-11-2021
┃mode : Desde 13-11-2019
┃𝖻𝖾𝖿𝗈𝗋𝖾 : 𝗏𝖾𝖾𝗋𝖻𝗈𝗍𝗓
╰─────────────────┈ ❁ཻུ۪۪⸙͎
MARKINHO O 𝖡𝖮𝖳
──────────────᯽────╯
╭┈──────ANOTAÇÕES
╰─➤⚒NOTAS📜
↣SE LIGAR = 𝖡𝖺𝗇+𝖡𝗅𝗈𝖼𝗄
↣FLODAR COMANDOS: 𝖡𝖺𝗇
↣Salva o ctt oficial aí pow
─────────────᯽────╯
╭┈─────MARKOS BOTZ
╰─❁۪۪
╰─➤ *${prefix}ownerbot*
╰─➤ *${prefix}adminbot*
╰─➤ *${prefix}funmenu*
╰─➤ *${prefix}mediamenu*
╰─➤ *${prefix}kerangmenu*
╰─➤ *${prefix}makermenu*
╰─➤ *${prefix}othermenu*
╰─➤ *${prefix}animemenu*
╰─➤ *${prefix}nsfwmenu*
╰─➤ *${prefix}vipmenu*
───────────────᯽──╯
 ╭─➤MARKOS BOT 
 │☗ 
 ╰─╯──────────᯽───╯
╰─➤ *${prefix}bugreport*
╰─➤  *${prefix}info*
╰─➤ *${prefix}owner*
╰─➤ *${prefix}request*
╰─➤ *${prefix}setprefix*
╰─➤ *${prefix}listblock*
╰─➤ *${prefix}iklan*
╰─➤ *${prefix}runtume*
╰─➤ *${prefix}rules*
╰─➤ *${prefix}tnc*
╰─➤ *${prefix}cekvip*
╰─➤ *${prefix}daftarvip*
╰─➤ *${prefix}addvip*
╰─➤ *${prefix}dellvip*
╰─➤ *${prefix}snk*
╰─➤ *${prefix}list*
╰─➤ *${prefix}𝚍𝚘𝚗𝚊𝚝𝚎*
╰─➤ *${prefix}fitnah*
╰─➤ *${prefix}totaluser*
╰─➤ *${prefix}level*
╰─➤ *${prefix}leveling*
╰─➤ *${prefix}glass*
──────────────᯽───╯
╭─➤ Passa no meu insta pow;
│☗ @markoswythor
╰─╯──────────᯽───╯
╰─➤ *${prefix}apiteks [teks]*
╰─➤ *${prefix}airteks [teks]*
╰─➤ *${prefix}metalteks [teks]*
╰─➤ *${prefix}mlogo [teks]*
╰─➤ *${prefix}ffbaner [teks]*
╰─➤ *${prefix}embun [teks]*
╰─➤ *${prefix}kunciteks [teks]*
╰─➤ *${prefix}say*
╰─➤ *${prefix}addsay [teks]*
╰─➤ *${prefix}listsay*
╰─➤ *${prefix}bacot*
╰─➤ *${prefix}addbacot [teks]*
╰─➤ *${prefix}listbacot*
╰─➤ *${prefix}resetbacot*
╰─➤ *${prefix}aguse*
╰─➤ *${prefix}kicktime*
╰─➤ *${prefix}nobg*
╰─➤ *${prefix}url2img*
╭┈────────────᯽───╯
╰➤ ATENÇÃO

   ➤ O bot não funciona 24hs por dia
   
╭─╯
╰➤ 𝗉𝖼 https://api.whatsapp.com/send?phone=5594988088531
      
「𝖯𝖾𝗌𝖺𝗇 𝖦𝖺 𝗉𝖾𝗇𝗍𝗂𝗇𝗀 𝖻𝗅𝗈𝗄!」
   ╭┈──────────᯽───╯
   ╰─➤ Agradecimentos:

    ➤ tio xande
    
    ➤ ySαท∂isx™
   
   ───────────᯽────╯
   
             ▉▍▏▐▕ ▋▊▊▕║▕▉▉ ▋
             ▉▍▏▐▕ ▋▊▊▕║▕▉▉ ▋
                       
          ©️ BY *Markos-BOT*
             
`
}
exports.help = help
	