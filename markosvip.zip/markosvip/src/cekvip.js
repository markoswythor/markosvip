const cekvip = () => { 
	return `           
──────────────────
*nome bot* :  MARKOS-BOT
──────────────────
        『 *𝐕𝐈𝐏 𝐔𝐒𝐄𝐑* 』
──────────────────
• *Status*    : *online*
────────────────── 
*Status Bot:* *on tbm krai🐊🤙*
────────────────── `
}
exports.cekvip = cekvip