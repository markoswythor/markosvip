const addsay = () => { 
	return `
	
	*ADD Message*
	
	Message  BERHASIL DISIMPAN KE DATA!
	

Thanks !`
}
exports.addsay = addsay