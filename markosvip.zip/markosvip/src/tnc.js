const tnc = () => { 
	return `       
	O código-fonte / bot é um programa de código aberto (gratuito) escrito usando Javascript, você pode usar, copiar, modificar, combinar, publicar, distribuir, sublicenciar.

Ao usar este código-fonte / bot, você concorda com os seguintes Termos e Condições:
- O código-fonte / bot não armazena seus dados em nossos servidores.
Este bot é gratuito, você pode fazê-lo, verifique a produção do markos
- O código-fonte / bot não é responsável pelos stickers que você faz desse bot e pelos vídeos, imagens ou outros dados que você obtém do código-fonte / bot.
- O código-fonte / bot não deve ser usado para serviços destinados / contribuídos em: 
    • sexo / tráfico humano
    • jogos de azar
    • comportamento viciante prejudicial
    • crime
    • violência (a menos que necessário para proteger a segurança pública)
    • queima / desmatamento florestal
    • discurso de ódio ou discriminação com base na idade, sexo, identidade de gênero, raça, sexualidade, religião, nacional`
    }
exports.tnc = tnc
