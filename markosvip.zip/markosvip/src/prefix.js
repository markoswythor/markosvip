const cekprefix = (prefix) => { 
	return `
	ESTE É O PREFIX GARAI *「* ${prefix} *」
	`
	}
exports.cekprefix = cekprefix