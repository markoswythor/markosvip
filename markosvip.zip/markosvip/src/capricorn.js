const capricorn = () => { 
	return `       
	
	Algumas das características que são bastante proeminentes nas pessoas que têm o zodíaco de Capricórnio são priorizar reputação, sucesso, posição, lealdade, status, sabedoria, medo de obstáculos, responsabilidade, pessimismo..`
	}
exports.capricorn = capricorn
	