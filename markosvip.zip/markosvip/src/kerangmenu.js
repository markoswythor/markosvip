const kerangmenu = (prefix) => { 
	return `
╭┈─────éomarkosdnv
╰─❁۪۪
╰─➤ *${prefix}apakah [optional]*
╰─➤ *${prefix}rate [optional]*
╰─➤ *${prefix}bisakah [optional]*
╰─➤ *${prefix}kapankah [optional]*
╰─➤ *${prefix}gantengcek*
╰─➤ *${prefix}toxic*
╰─➤ *${prefix}cantikcek*
╰─➤ *${prefix}persengay*
╭┈─────MARKOS OFFICIAL 
╰─❁۪۪`
}
exports.kerangmenu = kerangmenu