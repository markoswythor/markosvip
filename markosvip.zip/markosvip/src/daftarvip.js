const daftarvip = (prefix) => { 
	return `
	
*PREÇO DE LISTA VIP :*
-Rp. 5K > Ganha ViP
-Rp. 10K > markos VIP + Insira o bot em seu grupo!

*SE QUER REGISTAR VIP :*
*Proprietário do bate-papo BOT :*
_none *${prefix}owner*

*NOTE*
caso queira ganhar um vip insira o dono do bot em seu grupo 
wa.me/5594988088531

*GRUP WHATSAPP BOT :*
_none`
}
exports.daftarvip = daftarvip