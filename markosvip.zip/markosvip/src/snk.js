const snk = () => { 
	return `Termos e Condições do BOT * MARKOS * 
1. Não armazenamos fotos, vídeos, arquivos, áudios e documentos que você envia
2. Nunca pediremos que você forneça informações pessoais
3. Se você encontrar um bug / erro, informe diretamente ao proprietário do bot
Você também pode fazer sua própria votação, como ver o dono, sim, isso é uma produção do markos
4 - O que quer que você peça neste bot, NÃO SEREMOS RESPONSÁVEIS!

obrigado !`
}
exports.snk = snk
