const cancer = () => { 
	return `       
Cancer (21 Juni – 20 Juli)

Kanser (♋) (Grego antigo: Καρκίνος, latim: Câncer) é o quarto signo do zodíaco que vem da constelação de Câncer. Este signo do zodíaco inclui 90 ° a 120 ° do zodíaco, entre 90 ° e 120 ° do sistema de coordenadas celestes. Sob o zodíaco`
}
exports.cancer = cancer