const prefix = (prefix) => { 
	return `
	PREFIXOS ATUALMENTE USADOS *「* ${prefix} *」
	`
	}
exports.prefix = prefix