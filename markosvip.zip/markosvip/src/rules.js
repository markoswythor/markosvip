const rules = (prefix) => { 
	return `
*ANOTAÇÕES DO BOT*
    
➤ Use o atraso, não envie spam ao usar bots, pois as batatas grátis são todas empurradas.
➤ Bloqueio automático do bot de chamada / VC.
➤ Não chame / VC Bot se não estiver ativo.
➤ O bot não está ativo 24 horas, então depende se o proprietário está lá quando o bot também está ativado.

* Consequências por violar regras *
O bot irá bloquear você ou sair do grupo que você gerencia.

Essas regras são para a conveniência de todos que o usam
este bot
1. Não envie spam para bots.
CONSEQUÊNCIAS: * LEVA BLOCK *

2. Não telefone para o bot.
CONSEQUÊNCIAS: * BOCK SUAVE *

3. Não explore bots.
CONSEQUÊNCIAS: * BLOCK PERMANENTE *

Se as regras forem compreendidas, digite *${prefix}menu* para iniciar!`
}
exports.rules = rules