const aries = () => { 
	return `       
Aries (21 Maret – 20 April)

Aries (♈) /ˈɛəriːz/ (que significa "Ovelha") é a primeira constelação do Zodíaco, que inclui os primeiros 30 graus de longitude (0 ° ≤ λ <30 °). Sob o zodíaco tropical, o Sol transita nesta constelação geralmente entre 20 de março e 20 de abril
`
}
exports.aries = aries