const gemini = () => { 
	return `       
Gemini (21 Mei – 20 Juni)

Gêmeos (♊) [1] é o terceiro signo da constelação de Gêmeos. Sob o zodíaco tropical, o sol transita por este signo entre 21 de maio e 21 de junho. Gêmeos é representado pelos gêmeos Castor e Pollux.
`
}
exports.gemini = gemini